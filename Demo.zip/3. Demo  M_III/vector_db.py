"""
vector_db.py - Integration with Vector Databases (FAISS)

This module demonstrates the fourth step of the RAG pipeline: Integration with Vector Databases.
Once we have our text chunks and their embeddings, we store them in a Vector Database.
A Vector DB index allows us to perform fast, high-dimensional similarity searches (e.g., K-Nearest Neighbors).
We use FAISS (Facebook AI Similarity Search), which is an efficient, open-source local vector store.
"""

import os
from typing import List, Tuple
from langchain_core.documents import Document
from langchain_community.vectorstores import FAISS
from langchain_core.embeddings import Embeddings

def create_vector_store(documents: List[Document], embedding_model: Embeddings) -> FAISS:
    """
    Creates a FAISS vector database from a list of chunked documents and an embedding model.
    
    Args:
        documents (List[Document]): The text chunks to store.
        embedding_model (Embeddings): The embedding model to vectorize the text.
        
    Returns:
        FAISS: The initialized FAISS vector store.
    """
    print(f"[VectorDB] Creating FAISS index for {len(documents)} document chunks...")
    db = FAISS.from_documents(documents, embedding_model)
    print("[VectorDB] FAISS index created successfully.")
    return db

def save_vector_store(db: FAISS, folder_path: str):
    """
    Saves the FAISS index files locally to disk.
    
    Args:
        db (FAISS): The active FAISS vector store.
        folder_path (str): The folder where index files should be saved.
    """
    print(f"[VectorDB] Saving FAISS index locally to folder: {folder_path}")
    db.save_local(folder_path)
    print("[VectorDB] FAISS index saved successfully.")

def load_vector_store(folder_path: str, embedding_model: Embeddings) -> FAISS:
    """
    Loads a FAISS index from local disk storage.
    
    Args:
        folder_path (str): The folder containing the saved FAISS index files.
        embedding_model (Embeddings): The embedding model associated with the index.
        
    Returns:
        FAISS: The loaded FAISS vector store.
    """
    if not os.path.exists(folder_path):
        raise FileNotFoundError(f"FAISS index folder not found at: {folder_path}")
        
    print(f"[VectorDB] Loading FAISS index from folder: {folder_path}")
    
    # Note: allow_dangerous_deserialization=True is required by LangChain because
    # FAISS local storage uses Python's pickle module to serialize metadata.
    # We should only load files from trusted sources.
    db = FAISS.load_local(
        folder_path, 
        embedding_model, 
        allow_dangerous_deserialization=True
    )
    print("[VectorDB] FAISS index loaded successfully.")
    return db

def retrieve_similar_documents(
    db: FAISS, 
    query: str, 
    k: int = 3
) -> List[Tuple[Document, float]]:
    """
    Queries the FAISS vector database to retrieve the top K most similar document chunks.
    
    Args:
        db (FAISS): The active FAISS vector store.
        query (str): The search query.
        k (int): Number of top results to retrieve.
        
    Returns:
        List[Tuple[Document, float]]: A list of tuples containing (Document, L2 distance score).
                                      Note: Lower L2 distance means higher similarity.
    """
    print(f"[VectorDB] Searching FAISS database for query: '{query}' (Retrieving top {k})")
    
    # similarity_search_with_score returns the document and the L2 distance score
    results = db.similarity_search_with_score(query, k=k)
    return results

if __name__ == "__main__":
    # Self-test/demo execution when run directly
    print("--- VectorDB Module Self-Test ---")
    from embedder import get_embedding_model
    
    test_chunks = [
        Document(page_content="Apples are round, red or green fruits that grow on trees.", metadata={"source": "fruit_doc"}),
        Document(page_content="Carrots are orange root vegetables that grow underground.", metadata={"source": "veg_doc"}),
        Document(page_content="Bicycles are two-wheeled vehicles powered by pedaling.", metadata={"source": "bike_doc"}),
    ]
    
    embed_model = get_embedding_model()
    db = create_vector_store(test_chunks, embed_model)
    
    # Test saving & loading
    save_path = "temp_faiss_index"
    save_vector_store(db, save_path)
    
    try:
        loaded_db = load_vector_store(save_path, embed_model)
        
        # Test search query
        query = "What is a orange vegetable?"
        results = retrieve_similar_documents(loaded_db, query, k=1)
        
        doc, score = results[0]
        print(f"\nQuery: '{query}'")
        print(f"Top Retrieved Chunk: '{doc.page_content}'")
        print(f"Distance Score: {score:.4f} (Metadata: {doc.metadata})")
        
    finally:
        import shutil
        if os.path.exists(save_path):
            shutil.rmtree(save_path)
