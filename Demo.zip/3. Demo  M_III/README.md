# Edureka Demo: Modular RAG Pipeline with Hugging Face & FAISS

This folder contains a fully modular, step-by-step demonstration of building a **Retrieval-Augmented Generation (RAG)** pipeline. The codebase is structured specifically for teaching and demonstrating the key concepts of the RAG architecture as shown below:

```
                  ┌─────────────────────────────────────────┐
                  │          1. Components & Modules        │
                  │             (Overall System)            │
                  └────────────────────┬────────────────────┘
                                       │
                                       ▼
                  ┌─────────────────────────────────────────┐
                  │    2. Data Ingestion & Loaders          │
                  │             (loader.py)                 │
                  └────────────────────┬────────────────────┘
                                       │
                                       ▼
                  ┌─────────────────────────────────────────┐
                  │           3. Text Splitting             │
                  │            (splitter.py)                │
                  └────────────────────┬────────────────────┘
                                       │
                                       ▼
                  ┌─────────────────────────────────────────┐
                  │             4. Embeddings               │
                  │            (embedder.py)                │
                  └────────────────────┬────────────────────┘
                                       │
                                       ▼
                  ┌─────────────────────────────────────────┐
                  │     5. Integration with Vector DB       │
                  │            (vector_db.py)               │
                  └─────────────────────────────────────────┘
```

---

## 📂 Project Structure

This project follows a **modular architecture** using separate Python modules for each stage of the pipeline to help learners understand separation of concerns:

1. **`loader.py` (Data Ingestion & Document Loaders)**: Handles reading raw documents (`.txt` and `.pdf` files) and parsing them into LangChain Document objects.
2. **`splitter.py` (Text Splitting)**: Breaks large documents into smaller text chunks with defined lengths and overlaps using the `RecursiveCharacterTextSplitter`.
3. **`embedder.py` (Embeddings)**: Configures the Hugging Face embedding model (`sentence-transformers/all-MiniLM-L6-v2`) which maps text chunks to dense vectors.
4. **`vector_db.py` (Integration with Vector Databases)**: Handles saving chunk vectors inside a local **FAISS** index, persisting it to disk, loading it back, and executing similarity queries.
5. **`main.py` (CLI Interactive Script)**: A command-line script that executes the stages step-by-step, logging what happens at each stage (raw text size, chunks preview, vector values, and similarity score calculations).
6. **`app.py` (Streamlit Web Dashboard)**: An interactive web visualizer allowing students to upload files, configure chunk parameters, see overlapping boundaries, inspect vector listings, and run search queries in a beautiful GUI.
7. **`sample_document.txt`**: A default learning text file covering LLMs, Vector Databases, Hugging Face, and RAG.
8. **`requirements.txt`**: Dependencies list.

---

## 🚀 How to Run the Demo

### Prerequisites
Make sure you are in the directory:
```bash
cd "d:\Training\Edureka\Module 3\3. Demo  M_III"
```

If you haven't installed dependencies yet, run:
```bash
pip install -r requirements.txt
```

---

### Run Option A: Command Line Interface (CLI)

Run the sequential script to see log outputs and query the database in the console:
```bash
python main.py
```
Press **Enter** at each prompt to follow along with the RAG pipeline steps. You will be able to input search queries once the index finishes loading.

---

### Run Option B: Interactive Web Dashboard (Streamlit)

Start the local web dashboard for an interactive, graphical visualization:
```bash
streamlit run app.py
```
This will automatically launch the dashboard in your web browser (usually at `http://localhost:8501`). Explore each tab to visualize the data flow and experiment with chunk sizes!
