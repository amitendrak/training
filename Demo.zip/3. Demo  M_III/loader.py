"""
loader.py - Data Ingestion and Document Loaders

This module demonstrates the first step of the RAG pipeline: Data Ingestion.
It uses LangChain's document loaders to read and parse documents from different
formats (text and PDF) into standard LangChain Document objects.
"""

import os
from typing import List
from langchain_core.documents import Document
from langchain_community.document_loaders import TextLoader, PyPDFLoader

def load_document(file_path: str) -> List[Document]:
    """
    Loads a document from the specified file path based on its extension.
    
    Args:
        file_path (str): The absolute or relative path to the file.
        
    Returns:
        List[Document]: A list of LangChain Document objects containing page content and metadata.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file at {file_path} was not found.")
        
    ext = os.path.splitext(file_path)[1].lower()
    
    print(f"[Loader] Loading file: {file_path} (Type: {ext})")
    
    if ext == ".txt":
        # TextLoader loads a plain text file as a single document
        loader = TextLoader(file_path, encoding="utf-8")
        return loader.load()
        
    elif ext == ".pdf":
        # PyPDFLoader parses a PDF file page-by-page, creating a Document for each page
        loader = PyPDFLoader(file_path)
        return loader.load()
        
    else:
        raise ValueError(f"Unsupported file format '{ext}'. Only .txt and .pdf are supported in this demo.")

if __name__ == "__main__":
    # Self-test/demo execution when run directly
    print("--- Loader Module Self-Test ---")
    
    # Create a quick temp file for testing
    temp_test_file = "temp_test_doc.txt"
    with open(temp_test_file, "w", encoding="utf-8") as f:
        f.write("Hello learners! This is a test document for demonstrating Data Ingestion and Document Loaders.")
        
    try:
        docs = load_document(temp_test_file)
        print(f"Successfully loaded {len(docs)} document(s).")
        print(f"Content preview: '{docs[0].page_content}'")
        print(f"Metadata: {docs[0].metadata}")
    finally:
        if os.path.exists(temp_test_file):
            os.remove(temp_test_file)
