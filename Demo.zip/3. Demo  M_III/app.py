"""
app.py - Modular RAG Pipeline Visualizer (Focused Edition)

This Streamlit application demonstrates a RAG pipeline by allowing users to:
1. Upload a document (TXT or PDF).
2. Split it into chunks using RecursiveCharacterTextSplitter.
3. Inspect a selected chunk to view its raw text and corresponding Hugging Face embedding vector side-by-side.
4. Perform semantic search query retrieval using a FAISS vector database.
"""

import os
import streamlit as st
import tempfile
import pandas as pd

# Import our custom modules
from loader import load_document
from splitter import split_documents
from embedder import get_embedding_model
from vector_db import create_vector_store, retrieve_similar_documents

# Set page config
st.set_page_config(
    page_title="RAG Chunk & Embedding Visualizer",
    page_icon="🤖",
    layout="wide"
)

# App Custom CSS for a clean, professional look
st.markdown("""
<style>
    .reportview-container {
        background: #f8f9fa;
    }
    .main-title {
        color: #0b3c5d;
        font-family: 'Outfit', sans-serif;
        font-weight: 700;
        margin-bottom: 5px;
    }
    .subtitle {
        color: #328cc1;
        font-size: 1.15rem;
        margin-bottom: 25px;
    }
    .section-header {
        color: #0b3c5d;
        border-bottom: 2px solid #328cc1;
        padding-bottom: 5px;
        margin-top: 25px;
        margin-bottom: 15px;
    }
    .chunk-card {
        background-color: #f1f3f5;
        border-left: 5px solid #0b3c5d;
        padding: 15px;
        border-radius: 4px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .result-card {
        background-color: white;
        border-left: 5px solid #28a745;
        padding: 15px;
        border-radius: 4px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        margin-bottom: 15px;
    }
    .score-badge {
        background-color: #d1ecf1;
        color: #0c5460;
        padding: 3px 10px;
        border-radius: 12px;
        font-weight: bold;
        font-size: 0.85rem;
    }
    .vector-box {
        font-family: monospace;
        font-size: 0.85rem;
        background-color: #343a40;
        color: #f8f9fa;
        padding: 10px;
        border-radius: 4px;
        max-height: 180px;
        overflow-y: auto;
    }
</style>
""", unsafe_allow_html=True)

# Main Title
st.markdown("<h1 class='main-title'>🤖 Modular RAG: Chunk & Embedding Visualizer</h1>", unsafe_allow_html=True)
st.markdown("<p class='subtitle'>Upload a document, select individual text chunks to inspect their Hugging Face embedding vectors, and run semantic queries using FAISS!</p>", unsafe_allow_html=True)

# --------------------------------------------------------------------------
# SIDEBAR: Parameters
# --------------------------------------------------------------------------
st.sidebar.header("⚙️ RAG Configuration")

chunk_size = st.sidebar.slider(
    "Chunk Size (Characters)", 
    min_value=100, 
    max_value=2000, 
    value=500, 
    step=50,
    help="Target size of each text segment."
)

chunk_overlap = st.sidebar.slider(
    "Chunk Overlap (Characters)", 
    min_value=0, 
    max_value=500, 
    value=50, 
    step=10,
    help="Characters shared between adjacent chunks to maintain context."
)

retrieve_k = st.sidebar.slider(
    "Retrieval: Top K Results", 
    min_value=1, 
    max_value=5, 
    value=3,
    help="Number of similar chunks to retrieve from the vector database."
)

# Load Embedding model (cached to prevent reloading on every interaction)
@st.cache_resource(show_spinner=False)
def load_cached_embeddings():
    return get_embedding_model()

with st.spinner("Loading Hugging Face embedding model (sentence-transformers)..."):
    embeddings = load_cached_embeddings()

# --------------------------------------------------------------------------
# STEP 1: Document Upload & Ingestion
# --------------------------------------------------------------------------
st.markdown("<h3 class='section-header'>📂 1. Document Upload & Ingestion</h3>", unsafe_allow_html=True)

col_upload, col_meta = st.columns([2, 1])

uploaded_file = None
documents = None

with col_upload:
    uploaded_file = st.file_uploader(
        "Upload a document (.txt or .pdf):", 
        type=["txt", "pdf"],
        help="Upload a file to start chunking and generating embeddings."
    )

# Fallback to sample document if nothing is uploaded
use_sample = False
if not uploaded_file:
    with col_upload:
        use_sample = st.checkbox("Use default sample document", value=True)

# Load document
if uploaded_file:
    # Save to temp file
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as temp_file:
        temp_file.write(uploaded_file.getbuffer())
        temp_file_path = temp_file.name
    
    try:
        documents = load_document(temp_file_path)
        for doc in documents:
            doc.metadata["source"] = uploaded_file.name
    except Exception as e:
        st.error(f"Error loading document: {e}")
    finally:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)

elif use_sample:
    sample_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_document.txt")
    if os.path.exists(sample_path):
        documents = load_document(sample_path)
    else:
        st.error("Sample document not found. Please upload a file.")

# Display document metadata if loaded
if documents:
    total_chars = sum(len(doc.page_content) for doc in documents)
    with col_meta:
        st.info("📊 Document Statistics")
        st.write(f"**Filename:** `{documents[0].metadata.get('source', 'Unknown')}`")
        st.write(f"**Total Pages/Items:** `{len(documents)}`")
        st.write(f"**Total Characters:** `{total_chars}`")
else:
    st.info("Waiting for document upload...")
    st.stop()

# --------------------------------------------------------------------------
# STEP 2: Text Splitting & Chunk Selection
# --------------------------------------------------------------------------
st.markdown("<h3 class='section-header'>✂️ 2. Text Splitting & Chunk Embedding Inspector</h3>", unsafe_allow_html=True)

# Run splitter
chunks = split_documents(documents, chunk_size=chunk_size, chunk_overlap=chunk_overlap)

if chunks:
    # Let user select a particular chunk
    col_select, col_empty = st.columns([1, 2])
    with col_select:
        chunk_index = st.selectbox(
            f"Select a chunk to inspect (1 to {len(chunks)}):", 
            options=range(1, len(chunks) + 1),
            index=0
        )
    
    selected_chunk = chunks[chunk_index - 1]
    chunk_text = selected_chunk.page_content
    
    # Generate embedding for the specific selected chunk
    with st.spinner("Computing embedding for selected chunk..."):
        # embed_query yields a 384-element float list for the text
        chunk_vector = embeddings.embed_query(chunk_text)
    
    # Layout selected chunk and its embedding side-by-side
    col_chunk, col_embed = st.columns(2)
    
    with col_chunk:
        st.markdown(f"#### 📄 Chunk #{chunk_index} Text")
        st.markdown(f"**Character Length:** `{len(chunk_text)}` characters")
        st.markdown(f"""
        <div class="chunk-card">
            {chunk_text}
        </div>
        """, unsafe_allow_html=True)
        
    with col_embed:
        st.markdown("#### 🧬 Hugging Face Embedding Vector")
        st.write(f"**Model:** `sentence-transformers/all-MiniLM-L6-v2` | **Dimensions:** `{len(chunk_vector)}` float values")
        
        # Display sample vector dimensions
        st.write("**Vector Preview (First 8 dimensions):**")
        st.code(str(chunk_vector[:8]))
        
        # Display full vector inside scroll box
        st.write("**Full Dense Vector Array:**")
        st.markdown(f'<div class="vector-box">{str(chunk_vector)}</div>', unsafe_allow_html=True)
        
        # Simple profile bar chart of the vector
        st.bar_chart(chunk_vector[:80])
        st.caption("Visual profile showing values of the first 80 dimensions of the embedding vector.")

# --------------------------------------------------------------------------
# STEP 3: Vector DB & Similarity Retrieval
# --------------------------------------------------------------------------
st.markdown("<h3 class='section-header'>🔍 3. Vector Database Integration & Retrieval</h3>", unsafe_allow_html=True)

# Build FAISS vector database from chunks
with st.spinner("Indexing chunks in FAISS vector database..."):
    vector_db = create_vector_store(chunks, embeddings)

# Similarity Search Query Input
user_query = st.text_input(
    "Enter search query to retrieve similar chunks:", 
    value="What is Retrieval-Augmented Generation?"
)

if user_query:
    with st.spinner(f"Searching for matches..."):
        results = retrieve_similar_documents(vector_db, user_query, k=retrieve_k)
        
    st.markdown(f"#### Top {len(results)} Semantically Relevant Chunks")
    st.markdown("""
    *Note: Similarity is measured in **L2 (Euclidean) Distance**. A **lower score** means the vectors are closer together (higher semantic match).*
    """)
    
    for idx, (doc, score) in enumerate(results):
        st.markdown(f"""
        <div class="result-card">
            <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                <span style="font-weight: bold; color: #0b3c5d;">Rank #{idx + 1} Match</span>
                <span class="score-badge">Similarity Distance (L2): {score:.4f}</span>
            </div>
            <div style="font-size: 0.8rem; color: #666; margin-bottom: 8px;">Source: {doc.metadata.get('source', 'Unknown')}</div>
            <div style="font-size: 0.95rem; line-height: 1.5; color: #212529;">{doc.page_content}</div>
        </div>
        """, unsafe_allow_html=True)
