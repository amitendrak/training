"""
main.py - Modular RAG Pipeline CLI Demo

This script demonstrates the entire RAG pipeline process step-by-step for learners:
1. Data Ingestion & Document Loaders
2. Text Splitting (Chunking)
3. Embeddings generation using Hugging Face
4. Integration with Vector Databases (FAISS)
5. Document Retrieval based on queries

Run this script directly in your terminal to see the process in action.
"""

import os
import shutil

# Import our custom modules
from loader import load_document
from splitter import split_documents
from embedder import get_embedding_model
from vector_db import create_vector_store, save_vector_store, load_vector_store, retrieve_similar_documents

# Define paths
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__)) if "__file__" in locals() else os.getcwd()
SAMPLE_DOC_PATH = os.path.join(CURRENT_DIR, "sample_document.txt")
FAISS_STORE_PATH = os.path.join(CURRENT_DIR, "faiss_index_store")

def run_rag_demo():
    print("=" * 80)
    print("      EDUCREKA DEMO: BUILDING A MODULAR RAG PIPELINE FROM SCRATCH")
    print("=" * 80)
    print("\nIn this demonstration, we walk through the core components of RAG:")
    print("1. Data Ingestion & Document Loaders")
    print("2. Text Splitting")
    print("3. Hugging Face Embeddings")
    print("4. Integration with Vector Databases (FAISS)")
    print("5. Document Retrieval based on Query")
    print("-" * 80)
    
    # --------------------------------------------------------------------------
    # STEP 1: Data Ingestion and Document Loaders
    # --------------------------------------------------------------------------
    print("\n>>> STEP 1: DATA INGESTION AND DOCUMENT LOADERS")
    print("Goal: Read raw files and parse them into LangChain Document objects.")
    if not os.path.exists(SAMPLE_DOC_PATH):
        print(f"Error: Sample file not found at {SAMPLE_DOC_PATH}")
        return
        
    raw_docs = load_document(SAMPLE_DOC_PATH)
    print(f"-> Loaded {len(raw_docs)} document(s).")
    print(f"-> Total length of document: {len(raw_docs[0].page_content)} characters.")
    print(f"-> Sample metadata: {raw_docs[0].metadata}")
    print("\nPress Enter to proceed to Step 2...")
    input()
    
    # --------------------------------------------------------------------------
    # STEP 2: Text Splitting
    # --------------------------------------------------------------------------
    print("\n>>> STEP 2: TEXT SPLITTING (CHUNKING)")
    print("Goal: Divide the long document into smaller, manageable overlapping segments.")
    print("We set chunk_size=400 characters and chunk_overlap=50 characters.")
    
    chunk_size = 400
    chunk_overlap = 50
    chunks = split_documents(raw_docs, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    
    print(f"-> Created {len(chunks)} chunks from the document.")
    print("\nLet's view a sample chunk:")
    print(f"--- Chunk #3 Preview (Length: {len(chunks[2].page_content)} chars) ---")
    print(chunks[2].page_content)
    print("-" * 40)
    print("\nPress Enter to proceed to Step 3...")
    input()
    
    # --------------------------------------------------------------------------
    # STEP 3: Embeddings
    # --------------------------------------------------------------------------
    print("\n>>> STEP 3: EMBEDDINGS (HUGGING FACE MODEL)")
    print("Goal: Convert text chunks into numerical vectors containing semantic meaning.")
    print("We load 'sentence-transformers/all-MiniLM-L6-v2' (completely locally).")
    
    embeddings = get_embedding_model()
    
    # Let's show how an embedding looks like
    sample_text = "What is Retrieval-Augmented Generation?"
    sample_vector = embeddings.embed_query(sample_text)
    
    print(f"\n-> Vectorizing sample text: '{sample_text}'")
    print(f"-> Generated Vector Dimensions: {len(sample_vector)}")
    print(f"-> Sample vector values (first 5 dimensions): {sample_vector[:5]}")
    print("\nPress Enter to proceed to Step 4...")
    input()
    
    # --------------------------------------------------------------------------
    # STEP 4: Integration with Vector Databases
    # --------------------------------------------------------------------------
    print("\n>>> STEP 4: INTEGRATION WITH VECTOR DATABASES (FAISS)")
    print("Goal: Store the generated chunk embeddings in a local FAISS index for fast retrieval.")
    
    # Remove old index directory if exists
    if os.path.exists(FAISS_STORE_PATH):
        shutil.rmtree(FAISS_STORE_PATH)
        
    db = create_vector_store(chunks, embeddings)
    save_vector_store(db, FAISS_STORE_PATH)
    
    print(f"-> FAISS Index files saved in directory: {FAISS_STORE_PATH}")
    print("\nPress Enter to proceed to Step 5 (Retrieval)...")
    input()
    
    # --------------------------------------------------------------------------
    # STEP 5: Document Retrieval based on Query
    # --------------------------------------------------------------------------
    print("\n>>> STEP 5: DOCUMENT RETRIEVAL BASED ON QUERY")
    print("Goal: Retrieve the most semantically relevant chunks for a user search query.")
    print("We load our FAISS index from disk and run queries against it.")
    
    # Load vector store from disk
    vector_db = load_vector_store(FAISS_STORE_PATH, embeddings)
    
    # Start an interactive query loop
    print("\nYou can now search the loaded document! Try queries like:")
    print(" - 'What is RAG?'")
    print(" - 'What does FAISS stand for?'")
    print(" - 'What is Hugging Face?'")
    print(" - 'What are the limitations of LLMs?'")
    
    while True:
        print("\n" + "=" * 40)
        query = input("Enter search query (or type 'exit' to quit): ").strip()
        if not query:
            continue
        if query.lower() == 'exit':
            break
            
        print(f"\nSearching for: '{query}'...")
        results = retrieve_similar_documents(vector_db, query, k=2)
        
        print("\n--- RETRIEVED SEARCH RESULTS ---")
        for i, (doc, score) in enumerate(results):
            # score returned by FAISS with similarity_search_with_score is L2 distance.
            # Lower score = closer distance = higher similarity.
            print(f"\nResult #{i+1} [Similarity Score (L2 Distance): {score:.4f}]")
            print(f"Source: {doc.metadata.get('source', 'Unknown')}")
            print(f"Content:")
            print("-" * 50)
            print(doc.page_content)
            print("-" * 50)
            
    print("\nClean up: Removing temporary FAISS index...")
    if os.path.exists(FAISS_STORE_PATH):
        shutil.rmtree(FAISS_STORE_PATH)
    print("Demo completed! You have learned the entire modular RAG process.")

if __name__ == "__main__":
    run_rag_demo()
