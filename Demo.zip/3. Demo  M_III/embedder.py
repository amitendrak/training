"""
embedder.py - Embeddings with Hugging Face Models

This module demonstrates the third step of the RAG pipeline: Embeddings.
Embeddings convert text into a dense vector of numbers (e.g. 384 dimensions for all-MiniLM-L6-v2).
These vectors capture the semantic meaning of the text. Sentences with similar meanings
will be closer together in the vector space, enabling semantic search rather than just keyword matching.
We use the Hugging Face model `sentence-transformers/all-MiniLM-L6-v2` via LangChain's HuggingFaceEmbeddings.
"""

try:
    from langchain_huggingface import HuggingFaceEmbeddings
except ImportError:
    from langchain_community.embeddings import HuggingFaceEmbeddings

def get_embedding_model(model_name: str = "sentence-transformers/all-MiniLM-L6-v2") -> HuggingFaceEmbeddings:
    """
    Initializes and returns a HuggingFaceEmbeddings model.
    This model runs entirely locally and downloads the weights if they are not already cached.
    
    Args:
        model_name (str): The Hugging Face model name. Defaults to 'sentence-transformers/all-MiniLM-L6-v2'.
        
    Returns:
        HuggingFaceEmbeddings: The embedding model instance.
    """
    print(f"[Embedder] Loading Hugging Face Embedding Model: {model_name}")
    
    # We specify the model name and configure device options (like CPU/CUDA, defaults to CPU if no GPU)
    embeddings = HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True} # Normalize to compute cosine similarity easily
    )
    
    print("[Embedder] Embedding model loaded successfully.")
    return embeddings

if __name__ == "__main__":
    # Self-test/demo execution when run directly
    print("--- Embedder Module Self-Test ---")
    embedder = get_embedding_model()
    
    test_text = "Hugging Face embeddings are awesome!"
    vector = embedder.embed_query(test_text)
    
    print(f"Text: '{test_text}'")
    print(f"Generated Vector Dimension: {len(vector)}")
    print(f"Preview (first 5 numbers): {vector[:5]}")
