"""
splitter.py - Text Splitting and Chunking

This module demonstrates the second step of the RAG pipeline: Text Splitting.
Since LLM context windows and embedding models have length limits, we must split
long documents into smaller, semantically coherent chunks.
We use LangChain's RecursiveCharacterTextSplitter, which splits text by a list
of characters (like double newlines, single newlines, spaces) recursively to
keep paragraphs and sentences together as much as possible.
"""

from typing import List
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

def split_documents(
    documents: List[Document], 
    chunk_size: int = 500, 
    chunk_overlap: int = 50
) -> List[Document]:
    """
    Splits a list of LangChain Documents into smaller chunks.
    
    Args:
        documents (List[Document]): The raw loaded documents.
        chunk_size (int): The maximum size of each chunk (in characters).
        chunk_overlap (int): The number of characters to overlap between adjacent chunks.
                             This ensures context is not lost at splitting boundaries.
                             
    Returns:
        List[Document]: A list of chunked Document objects.
    """
    print(f"[Splitter] Splitting {len(documents)} document(s) with chunk_size={chunk_size}, chunk_overlap={chunk_overlap}")
    
    # RecursiveCharacterTextSplitter attempts to split on logical separators: "\n\n", "\n", " ", ""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        is_separator_regex=False
    )
    
    chunks = splitter.split_documents(documents)
    print(f"[Splitter] Created {len(chunks)} text chunks.")
    return chunks

if __name__ == "__main__":
    # Self-test/demo execution when run directly
    print("--- Splitter Module Self-Test ---")
    test_docs = [
        Document(
            page_content="LangChain is a framework for developing applications powered by language models. "
                         "It enables applications that are context-aware and reason. "
                         "A typical LangChain application consists of multiple components. "
                         "These components include loaders, splitters, embedders, and vector databases."
        )
    ]
    
    chunks = split_documents(test_docs, chunk_size=80, chunk_overlap=20)
    for i, chunk in enumerate(chunks):
        print(f"Chunk {i+1} ({len(chunk.page_content)} chars): '{chunk.page_content}'")
