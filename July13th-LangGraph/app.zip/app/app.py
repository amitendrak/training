"""Streamlit UI bringing together state/memory, agent+tools, HITL approval, and long-term memory."""

import streamlit as st
from langchain_core.messages import HumanMessage

from graph import graph

st.set_page_config(page_title="LangGraph Demo")
st.title("LangGraph Demo: State, Memory, Agent, HITL")

if "thread_id" not in st.session_state:
    st.session_state.thread_id = "streamlit-thread-1"
if "messages" not in st.session_state:
    st.session_state.messages = []
if "pending_tool_calls" not in st.session_state:
    st.session_state.pending_tool_calls = None

user_id = st.sidebar.text_input("User ID", value="sri")
st.sidebar.caption("Try: 'What's the status of order 4521?' or 'Remember that I prefer short answers.'")
config = {"configurable": {"thread_id": st.session_state.thread_id, "user_id": user_id}}

for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

if st.session_state.pending_tool_calls:
    st.warning(f"Agent wants to call: {st.session_state.pending_tool_calls}")
    if st.button("Approve tool call"):
        result = graph.invoke(None, config)
        st.session_state.pending_tool_calls = None
        st.session_state.messages.append({"role": "assistant", "content": result["messages"][-1].content})
        st.rerun()
else:
    user_input = st.chat_input("Message the agent")
    if user_input:
        st.session_state.messages.append({"role": "user", "content": user_input})
        result = graph.invoke({"messages": [HumanMessage(content=user_input)]}, config)
        last_message = result["messages"][-1]
        if last_message.tool_calls:
            st.session_state.pending_tool_calls = last_message.tool_calls
        else:
            st.session_state.messages.append({"role": "assistant", "content": last_message.content})
        st.rerun()
