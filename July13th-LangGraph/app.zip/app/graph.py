"""Combines state/messages memory, an agent with tools, HITL approval, and long-term memory."""

from dotenv import load_dotenv
from langchain_core.messages import trim_messages
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, MessagesState, START, END
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore

from memory import get_profile, remember_preference

load_dotenv()

llm = ChatOpenAI(model="gpt-4o-mini")
store = InMemoryStore()  # long-term memory: shared across threads
checkpointer = MemorySaver()  # short-term memory: per conversation thread


@tool
def get_order_status(order_id: str) -> str:
    """Look up the status of an order."""
    return f"Order {order_id} is out for delivery."


@tool
def save_preference(user_id: str, preference: str) -> str:
    """Save a user preference to long-term memory."""
    remember_preference(store, user_id, preference)
    return f"Saved preference for {user_id}: {preference}"


tools = [get_order_status, save_preference]
llm_with_tools = llm.bind_tools(tools)


def agent_node(state, config):
    user_id = config["configurable"]["user_id"]
    profile = get_profile(store, user_id)
    system = {"role": "system", "content": f"User profile (long-term memory): {profile}"}
    trimmed = trim_messages(state["messages"], max_tokens=1000, strategy="last", token_counter=llm)
    response = llm_with_tools.invoke([system] + trimmed)
    return {"messages": [response]}


builder = StateGraph(MessagesState)
builder.add_node("agent", agent_node)
builder.add_node("tools", ToolNode(tools))
builder.add_edge(START, "agent")
builder.add_conditional_edges("agent", tools_condition)
builder.add_edge("tools", "agent")

# interrupt_before="tools" -> UX/HITL: pause for human approval before any tool runs
graph = builder.compile(checkpointer=checkpointer, store=store, interrupt_before=["tools"])
