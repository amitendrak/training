"""Helper functions for the long-term memory store (memory schema: {"name": str, "preferences": list[str]})."""

DEFAULT_PROFILE = {"name": "", "preferences": []}


def get_profile(store, user_id):
    namespace = ("users", user_id)
    item = store.get(namespace, "profile")
    return item.value if item else dict(DEFAULT_PROFILE)


def save_profile(store, user_id, profile):
    namespace = ("users", user_id)
    store.put(namespace, "profile", profile)


def remember_preference(store, user_id, preference):
    profile = get_profile(store, user_id)
    if preference not in profile["preferences"]:
        profile["preferences"].append(preference)
    save_profile(store, user_id, profile)
